ArrayXd v = ArrayXd::LinSpaced(5,0,1);
cout << sinh(v) << endl;
